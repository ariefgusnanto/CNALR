cv.log.sparse <-
function(y,X=1,Z, fold=5, penalty="HL", lambda.seq=exp(seq(-2,6,0.5)), tolerance=1e-4, write=NULL, plot.all=FALSE, seed=NULL,  opt.crit = "AIC", alpha.mix=0.5, alpha=1.00001, zero.threshold=NULL, fixed.b0=TRUE, epsilon=1e-3){
    # CROSS VALIDATION Logistic regression with HL random effects
    # for sparse estimation based on Lee and Oh (2006)
    # input: X, matrix of fixed predictors, default: 1 (fixed intercept)
    # Z, matrix of genomic data
    # penalty, either "L1", "SCAD", "ridge",  "HL", "HLnet", "HLIG", or "HLIGnet" (strict)
    # lambda.seq, sequence of lambda to be run
    # tolerance, convergence criterion
    # write, if not NULL, the path to store the value of some key quantities
    #      in the iteration -- leave it NULL, unless you know what they mean
    # plot.all, logical, shall a plot of criterion be done?
    # seed, if NULL, it will not be set (let the computer decides)
    # cv.log.sparse uses log.sparse for cross validation
    
    # Contact: A.Gusnanto@leeds.ac.uk
    
    y.pred.fun <- function (X = NULL, Z = NULL, beta = NULL, b = NULL) {
        Z = as.matrix(Z)
        beta = as.matrix(beta)
        eta = X %*% beta + (Z %*% b)
        p = abs(exp(eta)/(1 + exp(eta))-0.000001)
        return(round(p))
    }# End of Yfun function
    
    n=dim(Z)[1]  # number of samples
    q=dim(Z)[2]  # number of random effects
    if(length(c(X))==1) X=rep(X,n)
    X = as.matrix(X)
    nc=dim(X)[2]
    
    # folding groups
    if(!is.null(seed)) set.seed(seed)
    n.y1 <- sum(y==1)
    n.y0 <- sum(y==0)
    fold1 <- sample(c(1:n.y1)%%fold)+1
    fold0 <- sample(c(1:n.y0)%%fold)+1
    fold.group <- vector()
    fold.group[y==1] <- fold1
    fold.group[y==0] <- fold0
    
    # vectors across different lambdas
    pred.error = NULL # matrix of prediction error across
    # different folds (row) and different lambdas (column)
    y.pred.matrix = NULL # matrix of y.pred across different folds (row)
    # and different lambdas (column)
    y.val.vector = NULL # vector of y.val across folds
    
    for(k in 1:fold){
        Z.val <- Z[fold.group==k,]
        Z.est <- Z[fold.group!=k,]
        y.val <- y[fold.group==k]
        y.est <- y[fold.group!=k]
        X.val <- X[fold.group==k,]
        X.est <- X[fold.group!=k,]
        
        y.val.vector <- c(y.val.vector, y.val) # to be compared to y.pred.matrix
        
        res.fold <- log.sparse(y=y.est,X=X.est,Z=Z.est, penalty=penalty, lambda.seq=lambda.seq, tolerance=tolerance, write=write, plot.all=plot.all,  opt.crit =opt.crit, alpha.mix=alpha.mix, alpha=alpha, zero.threshold=zero.threshold, fixed.b0=fixed.b0, epsilon=epsilon)
        
        pred.error.fold <- NULL
        y.pred.fold <- NULL
        
        for(kk in 1:length(lambda.seq)){
            y.pred <- y.pred.fun(X = X.val, Z = Z.val, beta = res.fold$estimates$beta.matrix[,kk],
                                 b = res.fold$estimates$b.matrix[,kk])
            pred.error.fold <- c(pred.error.fold, sum(y.val!=y.pred))
            y.pred.fold <- cbind(y.pred.fold, y.pred)
        } # End iteration across lambda
        pred.error <- rbind(pred.error, pred.error.fold)
        y.pred.matrix <- rbind(y.pred.matrix, y.pred.fold)
    } # End of iteration across fold.
    
    mis.error <- apply(pred.error,2,sum)
    opt.error <- mis.error[which.min(mis.error)]
    
    #optimal lambda
    opt.lambda <- lambda.seq[which.min(mis.error)]
    
    estimates <- list(pred.error=pred.error, y.pred.fold = y.pred.matrix,
                      y.val.fold = y.val.vector)
    result <- list(lambda=opt.lambda, lambda.seq=lambda.seq,
                   log.lambda.seq=log(lambda.seq), error=opt.error,
                   error.seq=mis.error, estimates=estimates)
    return(result)
}
