log.sparse <-
function(y,X=1,Z, penalty="HL", lambda.seq=exp(seq(-2,6,0.5)), tolerance=1e-4, write=NULL, plot.all=FALSE, opt.crit = "AIC", alpha.mix=0.5, alpha=1.00001, zero.threshold=NULL, fixed.b0=TRUE, epsilon=1e-3){
# Logistic regression with HL random effects
# WITH ELASTIC NET type penalty
# for sparse estimation
# utilising HL likelihood of Lee and Oh (2006)
# input: X, matrix of fixed predictors, default: 1 (fixed intercept)
# Z, matrix of genomic data
# penalty, either "L1", "SCAD", "ridge", "HL", "enet", or "HLnet" (strict)
# (addition) or "HLIG" or "HLIGnet" for inverse gamma (strict)
# lambda.seq, sequence of lambda to be run
# tolerance, convergence criterion
# write, if not NULL, the path to store the value of some key quantities
#      in the iteration -- leave it NULL, unless you know what they mean
# plot.all, logical, shall a plot of criterion be done?
# opt.crit, optimal criterion to estimate lambda, either "AIC" or "BIC" (strict)
# alpha.mix, mixing proportion for HL in HLnet
# (addition) alpha, parameter for HLIG, should be close to one for sparse solution

# Note: Here there is the addition of steps
# in which estimates of random effects less than zero.threshold is set to zero.
# The threshold does not have an effect when penalty="ridge".

# Contact: A.Gusnanto@leeds.ac.uk

    Yfun <- function (X = NULL, y = NULL, Z = NULL, beta = NULL, b = NULL, N = 1, epsilon=1e-3) {
        Z = as.matrix(Z)
        eta = X %*% beta + (Z %*% b)
        p = abs(exp(eta)/(1 + exp(eta))-epsilon)
        wt = (N * p * (1 - p))+(epsilon*0.1)
        Y = eta + ((y - N * p)/(N * p * (1 - p) + epsilon))
        return(list(eta = c(eta), p = c(p), wt = c(wt), Y = c(Y)))
    }# End of Yfun function
    
solve1 <- function(Z,sinv,dinv){
d <- 1/dinv
s <- 1/sinv
temp <- t(Z)%*%solve(Z%*%diag(d)%*%t(Z)+diag(s))%*%Z
temp <- d*temp
temp <- -1*t(t(temp)*d)
diag(temp) <- d+diag(temp)
return(temp)
}

thresh = function(b, penalty, zero.threshold){
if(penalty=="ridge") zero.threshold = 0
if(penalty=="L1" | penalty=="HL" | penalty=="HLIG"){
 if(is.null(zero.threshold)) zero.threshold <- 1e-3}
if(penalty=="enet" | penalty=="HLnet" | penalty=="HLIGnet"){
 if(is.null(zero.threshold)) zero.threshold <- 1e-2}
b[abs(b) < zero.threshold] <- 0
return(b) 
}


    n=dim(Z)[1]  # number of samples
    q=dim(Z)[2]  # number of random effects
    if(length(c(X))==1) X=rep(X,n)
    X = as.matrix(X)
    nc=dim(X)[2]
    beta0=rep(mean(y),nc)  # fixed effects starting values
    #b0 = solve1(Z, sinv=rep(1,n), dinv=rep(median(lambda.seq), q)) %*% t(Z)%*%(y-X%*%beta0)
    # random effects starting values
    a<-3.7 # for SCAD
    w<-30  # for HL, sparse estimates
    b.matrix = NULL # matrix for random effects for different lambdas
    beta.matrix = NULL # matrix for fixed effects for different lambdas
                       # should be the same across columns.
                       # It is put here as a check.
    se.b.matrix = NULL # matrix for standard error of random effects
                       # for different lambdas
    se.beta.matrix = NULL # matrix for standard error of fixed effects
                          #for different lambdas
                          # should be different across columns (a function of lambda)
                          # It is put here as a check.
    AIC.vector = NULL # vector of AIC for each lambda
    BIC.vector = NULL # vector of BIC for each lambda
    df.vector = NULL # vector of df fit for Z (for each lambda)
    loglik.vector = NULL # vector of log likelihood (for each lambda)

    for(lamx in lambda.seq){ # Start iteration for different lambda
    tole=1e10
    iter=1
    beta= beta0
    if(fixed.b0){
     b0 = solve1(Z, sinv=rep(1,n), dinv=rep(1, q)) %*% t(Z)%*%(y-X%*%beta0)
    } else {
     b0 = solve1(Z, sinv=rep(1,n), dinv=rep(lamx, q)) %*% t(Z)%*%(y-X%*%beta0)
    }# end if else fixed.b0

    b = b0
    sigx<-sd(b0)/sqrt(2)

    if (lamx==0 & penalty=="SCAD") {lamx<-1e-10}

    while(tole>tolerance & iter<=5000){  # Start iteration for a given lambda
     cat("Penalty:", penalty, "log(lambda)",log(lamx),"iter",iter,"rss", tole, "\n")
     old.b = b 
    if (penalty=="L1") {uux<-abs(b)+1e-08}
    if (penalty=="SCAD") {uux<-(abs(b)+1e-08)/ (as.numeric(abs(b)<=lamx)+as.numeric(abs(b)>lamx)*(a*lamx-abs(b))*as.numeric(a*lamx>abs(b))/((a-1)*lamx))}
    if (penalty=="HL"){    kax <- sqrt(4*b^2/(w*sigx^2)+((2/w)-1)^2) ;    uux <- 0.25*w*(((2/w)-1)+kax)+1e-08 }
    if (penalty=="ridge"){uux <- rep(1,q)}
    if (penalty=="enet"){uux <- 0.5*(abs(b)+1e-08)+0.5}
    if (penalty=="HLnet"){ kax <- sqrt(4*b^2/(w*sigx^2)+((2/w)-1)^2) ; uux <- alpha.mix*(0.25*w*(((2/w)-1)+kax)+1e-08)+(1-alpha.mix) }
    if (penalty=="HLIG"){co <-1; alpha1 <- 2*alpha+3; alpha2 <- 2*co*(alpha-1); uux <- (b^2/(2*sigx^2) + alpha2)/alpha1+1e-08}
    if (penalty=="HLIGnet"){co <-1; alpha1 <- 2*alpha+3; alpha2 <- 2*co*(alpha-1); uux <- alpha.mix*((b^2/(2*sigx^2) + alpha2)/alpha1+1e-08)+(1-alpha.mix)}
    WWx<-as.vector(1/uux)

    res.fun = Yfun(X, y, Z, beta, b, 1, epsilon)
            Y = res.fun$Y

     if(!is.null(write)){
     write.table(t(c(iter, log(lamx), b)), file=paste(write,"-b.txt", sep=""), row.names=F, col.names=F, quote=F, append=T)
     write.table(t(c(iter, log(lamx),Y)), file=paste(write,"-Y.txt", sep=""), row.names=F, col.names=F, quote=F, append=T)
     write.table(t(c(iter, log(lamx),WWx)), file=paste(write,"-WWx.txt", sep=""), row.names=F, col.names=F, quote=F, append=T)
     write.table(t(c(iter, log(lamx),uux)), file=paste(write,"-uux.txt", sep=""), row.names=F, col.names=F, quote=F, append=T)
     write.table(t(c(iter, log(lamx),res.fun$wt)), file=paste(write,"-wt.txt", sep=""), row.names=F, col.names=F, quote=F, append=T)
     }

     beta= solve(t(X)%*%diag(res.fun$wt)%*%X, t(X)%*%diag(res.fun$wt)%*%(Y-Z%*%b))
     vmat <- solve1(Z, sinv=res.fun$wt, dinv=lamx*WWx)
     b= vmat %*% t(Z*res.fun$wt)%*%(Y-X%*%beta)
     b = thresh(c(b), penalty, zero.threshold)
     tole = sum((b-old.b)^2)
     iter = iter+1
     sigx <- sd(b)/sqrt(2)
     gc()
    } # end iteration for one given lambda

     b.matrix = cbind(b.matrix, c(b))  # random effects collection
     beta.matrix = cbind(beta.matrix, c(beta)) # fixed effects collection
     se.b.matrix = cbind(se.b.matrix, c(sqrt(diag(vmat)))) # se for b
     Vtemp <- t(t(Z)*c(1/(lamx*WWx)))%*%t(Z)+diag(1/c(res.fun$wt)) # ZD^{-1}Z'
     Vmat <- solve(t(X)%*%solve(Vtemp)%*%X) # (X'V^{-1}X)^{-1}
     se.beta.matrix = cbind(se.beta.matrix, c(sqrt(diag(Vmat)))) # se for beta

     # AIC and BIC calculation
     loglik = sum(y*log(res.fun$p)+(1-y)*log(1-res.fun$p))
     df.mat = vmat%*%t(Z*res.fun$wt)%*%Z
     df=sum(diag(df.mat))
     AIC.vector = c(AIC.vector, -2*loglik+2*df)
     BIC.vector = c(BIC.vector, -2*loglik+log(n)*df)
     df.vector = c(df.vector, df)
     loglik.vector = c(loglik.vector, loglik)
     
    }# end iteration for different lambdas
    
    if(plot.all & opt.crit=="AIC"){
    plot(log(lambda.seq), AIC.vector, type="l", ylab="AIC", 
       xlab=expression(paste("log(",lambda,")")))
    } # end of if(plot.all & opt.crit=="AIC")
    if(plot.all & opt.crit=="BIC"){
    plot(log(lambda.seq), BIC.vector, type="l", ylab="BIC", 
       xlab=expression(paste("log(",lambda,")")))
    } # end of if(plot.all & opt.crit=="BIC")

    # optimal lambda, df, loglik, etc.
    if(opt.crit == "BIC"){
    opt.lambda <- lambda.seq[which.min(BIC.vector)]
    opt.df <- df.vector[which.min(BIC.vector)]
    opt.loglik <- loglik.vector[which.min(BIC.vector)]
    bhat <- b.matrix[,which.min(BIC.vector)]
    se.bhat <- se.b.matrix[,which.min(BIC.vector)]
    betahat <- beta.matrix[,which.min(BIC.vector)]
    se.betahat <- se.beta.matrix[,which.min(BIC.vector)]
     } else {
    opt.lambda <- lambda.seq[which.min(AIC.vector)]
    opt.df <- df.vector[which.min(AIC.vector)]
    opt.loglik <- loglik.vector[which.min(AIC.vector)]
    bhat <- b.matrix[,which.min(AIC.vector)]
    se.bhat <- se.b.matrix[,which.min(AIC.vector)]
    betahat <- beta.matrix[,which.min(AIC.vector)]
    se.betahat <- se.beta.matrix[,which.min(AIC.vector)]
     }
    
     estimates = list(lambda.seq = lambda.seq, log.lambda.seq = log(lambda.seq),
     AIC.vector = AIC.vector, BIC.vector = BIC.vector,
     df.vector = df.vector, loglik.vector = loglik.vector,
     b.matrix = b.matrix, beta.matrix = beta.matrix,
     se.b.matrix = se.b.matrix, se.beta.matrix = se.beta.matrix)
     
    
    result <- list(lambda=opt.lambda, df=opt.df, loglik=opt.loglik,
     bhat=bhat, se.bhat=se.bhat,
     z.bhat = bhat/se.bhat, pval.bhat = pnorm(-abs(bhat/se.bhat))*2,
     lower.ci.bhat = bhat+qnorm(0.025)*se.bhat, upper.ci.bhat = bhat+qnorm(0.975)*se.bhat,
     betahat = betahat, se.betahat = se.betahat, z.betahat = betahat/se.betahat,
     pval.betahat = pnorm(-abs(betahat/se.betahat))*2,
     lower.ci.betahat = betahat+qnorm(0.025)*se.betahat,
     upper.ci.betahat = betahat+qnorm(0.975)*se.betahat,
     estimates = estimates)
     
    return(result)
}
