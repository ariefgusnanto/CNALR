plot.cv <-
function(x, ...){
# function to plot the results of cross validation of cv.log.sparse
# A.Gusnanto@leeds.ac.uk
plot(x$log.lambda.seq, x$error.seq, ...)
}
