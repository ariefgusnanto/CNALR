plot.sparse <-
function(x, type="l", ...){
plot(x$estimates$log.lambda, x$estimates$AIC.vector, type="l", ...)
lines(x$estimates$log.lambda, x$estimates$BIC.vector, col=2, ...)
}
